3 Mobiles - Realme, Redmi, Samsung

3 Laptops - Hp, Lenovo, Dell

3 T-shirts - US-polo, peter-england ,Tommy Hilfiger

3 Sarees - Any 3 sarees
 
3 Caps - adidas,Nike,Puma

4 Beaty and toys  Puma Shoes,Titan Watches

3 Grocery - gold winner coocking oil,Tata salt,Ashirvaad Chilli Powder

3 Pants Levi's,Jack & Jones, Calvin Klein.

modify cursole in all pages

Products
Products -> Computers
Products -> Books
Products -> Computers -> Desktop
Products -> Computers -> Laptops
Products -> Computers -> Laptops -> Accessories
Products -> Computers -> Accessories

