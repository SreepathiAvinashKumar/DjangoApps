Requirements

Python Modules

- pip install django
- pip install Pillow
- pip install django-crispy-forms
- Bootstrap

Tasks to do

1. Arrange the Products via Categories in the home page
2. Add the products to the ecommerce 
3. Change the Order page Logo 
4. Change the favicon icon of the ecommerce.
5. change the title of the page
6. Discount and Tax Adding to the cart page
