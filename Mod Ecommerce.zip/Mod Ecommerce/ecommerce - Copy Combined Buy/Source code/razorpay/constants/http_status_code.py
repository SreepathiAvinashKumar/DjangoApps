class HTTP_STATUS_CODE(object):
    OK = 200
    REDIRECT = 300
