from django.contrib import admin
from .models import Whishlist

admin.site.register(Whishlist)
