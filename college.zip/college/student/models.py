from django.db import models
from django.forms import ModelForm

class Student(models.Model):
      student_name = models.CharField(max_length=200)
      student_pin = models.CharField(max_length=200)
      student_rank = models.IntegerField(default=0)

class StudentForm(ModelForm):
      class Meta:
        model =Student
        fields =[ 'student_name','student_pin','student_rank' ]      


