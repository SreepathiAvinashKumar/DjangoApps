from django.shortcuts import render,redirect
from .models import Student,StudentForm
from django.http import HttpResponse
from django.contrib import messages

def home(request):
    return render(request,'home.html')


def index(request):
      return render(request,'index.html',{'s' : Student.objects.all()})

      

def new(request):
     if request.method =='POST':
        s = StudentForm(request.POST)
        s.save()
        messages.success(request,"Student Successfully Created")
        return redirect('student:index')
     else:
        context ={
         "form":StudentForm()
          }
        return render(request,'new.html',context)  


def edit(request,sid):
      std = Student.objects.get(pk=sid)
      if request.method == 'POST':
        form =StudentForm(request.POST,instance=std)
        form.save()
        messages.warning(request,"Student Successfully Updated")
        return redirect('student:index')
      else: 
        f = StudentForm(instance=std)
        context={
          "form":f,
          "s":sid
        }
        return render(request,'edit.html',context)

def delete(request,sid):
        s = Student.objects.get(pk=sid)
        s.delete()
        messages.error(request,"Student Successfully Deleted")
        return redirect('student:index')
       
def details(request,sid):
      s= Student.objects.get(pk=sid)
      context ={
       "st":s,
       "sid":sid
      }
      return render(request,'details.html',context)




                 

