from django.urls import path
from . import views

app_name = 'dict'
urlpatterns = [
    path('index', views.index, name='index'),
    path('word', views.word, name='word'),

]
