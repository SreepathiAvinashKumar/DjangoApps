from django.shortcuts import render, redirect
from django.http import HttpResponse
from PyDictionary import PyDictionary


def index(request):
    return render(request, 'index.html')


def word(request):
    searchis = request.POST['search']
    dictionary = PyDictionary()
    synonyms = dictionary.synonym(searchis)
    antonyms = dictionary.antonym(searchis)
    meaning = dictionary.meaning(searchis)

    context = {
        'searchis': searchis,
        'meaning': meaning,
        'synonyms': synonyms,
        'antonyms': antonyms,
    }
    return render(request, 'word.html', context)
